#include <cstdint>
#define SUM_H
#ifdef SUM_H

int64_t Sum(int64_t x, int64_t y);

#endif